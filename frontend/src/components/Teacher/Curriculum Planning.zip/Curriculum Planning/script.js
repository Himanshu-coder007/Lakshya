function inClassAddData() {
    var inClassValue = document.getElementById("in-class-input").value;
    var time1Value = document.getElementById("time1-input").value;
    
    var tbodyinclass = document.getElementById("in-class-content");
    
    var newRowInClass = tbodyinclass.insertRow();

    var inClassCell = newRowInClass.insertCell(0);
    var time1Cell = newRowInClass.insertCell(1);

    inClassCell.textContent = inClassValue;
    time1Cell.textContent = time1Value;

    document.getElementById("in-class-input").value = '';
    document.getElementById("time1-input").value = '';
}

function outOfClass() {
    var outOfClassValue = document.getElementById("out-of-class-input").value;
    var time2Value = document.getElementById("time2-input").value;

    var tbodyoutclass = document.getElementById("out-of-class-content");

    var newRowOutOfClass = tbodyoutclass.insertRow();

    var outOfClassCell = newRowOutOfClass.insertCell(0);
    var time2Cell = newRowInClass.insertCell(1);

    outOfClassCell.textContent = outOfClassValue;
    time2Cell.textContent = time2Value;

    document.getElementById("out-of-class-input").value = '';
    document.getElementById("time2-input").value = '';
}